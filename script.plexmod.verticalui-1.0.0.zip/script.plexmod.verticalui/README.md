# Plex Vertical UI Installer

Instalador de interfaz vertical para Plex for Kodi.

## Instalación

1. Instala este addon desde el ZIP
2. Ejecuta: Programas → Plex Vertical UI Installer
3. Selecciona "Instalar UI Vertical"
4. Ve a Configuración de Plex → Activa "Usar interfaz vertical"
5. Reinicia Plex

## Características

- Navegación vertical
- Diseño moderno
- Animaciones suaves
- Optimizado para mando

## Requisitos

- Kodi 19+
- script.plexmod instalado
