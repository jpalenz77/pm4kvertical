ARCHIVOS QUE DEBES COPIAR AQUÍ:

1. vertical_home.py
   - El archivo Python con la lógica de la UI vertical

2. script-plex-vertical-home.xml
   - El archivo XML con el diseño visual

Estos archivos deben copiarse desde donde los creaste originalmente.
