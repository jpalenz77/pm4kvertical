#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Plex Vertical UI - Settings XML
Configuration options for the standalone Plex client
"""